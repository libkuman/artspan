<div class="eventcal-list">
  <h3><?php print $fields['field_content_title_value']->content; ?></h3>
  <?php print $fields['field_date_value']->content; ?>
  <?php print $fields['address']->content; ?>
  <p><?php print $fields['field_teaser_value']->content; ?></p>
</div>
