<?php
  $node = content_profile_load('artist', arg(1));
  $title = $node->field_content_title[0]['value'];

  $image = $node->field_image[0];

  $contact = _artspan_get_civi_contact_public_location_info(arg(1));
  $websites = _artspan_get_artist_websites($contact['contact_id']);

  $artist_sites = array();
  foreach($websites as $website) {
    if($website->name == 'Twitter') {
      $twitter = $website;
      continue;
    }
    else if($website->name == 'Facebook') {
      $facebook = $website;
      continue;
    }
    else {
      $artist_sites[] = $website;
    }
  }
  if(count($artist_sites) == 0) {
    $websites = false;
  }
  $phone = $contact['phone'];
  $email = $contact['email'];
  $statement = $node->field_artist_statement[0]['value'];

  $openstudios = _artspan_get_openstudios_information($contact['contact_id']);

  function display_openstudios_weekend($number, $term, $parent, $contact) {
    print "<div class='weekend_$number'>";
    print '<a href="/sf-open-studios/overview">' . $parent->name . '</a><br /> <strong>Neighborhood: ' . $term->name . '</strong>';
    print '<div class="address">';
    if($contact["current_employer"] && $number == 10):
      print $contact["current_employer"] . '<br />';
    endif; 
    if($contact["address_os$number"]['use_shared_address']) {
      print $contact["address_os$number"]['shared']->display_name . '<br /> ';
    }
    if($contact["address_os$number"]['supplemental_address_1']) print $contact["address_os$number"]['supplemental_address_1'] . '<br />';
    print $contact["address_os$number"]['street_address'] . '<br />';
    if($contact["address_os$number"]['supplemental_address_2']) {
      $studio_info = $contact["address_os$number"]['supplemental_address_2'];
      $studio_no = strpos($studio_info, 'Studio Number:');
      if($studio_no) {
        print substr($studio_info, 0, $studio_no) . '<br />' . substr($studio_info, $studio_no) . '<br />';
      }
      else {
        print $studio_info . '<br />';
      }
    }
    print $contact["address_os$number"]['city'] . ', CA ' . $contact["address_os$number"]['postal_code'];
    print '</div>';
    print '</div>';
  }
?>
<div class="header-area">
  <h1><?php print $title; ?></h1>
  <?php if($openstudios): ?>
    <div class="sf-open-studios">SF Open Studios</div>
  <?php endif; ?>
  <div class="header-links">
    <div class="backlink">
      <?php print l('Back to Artists', 'artists'); ?>
    </div>
  </div>
</div>

<?php if($image || $websites || $phone || $email || $statement || $twitter || $facebook): ?>
  <div class="profile">
    <?php if($image): ?>
      <div class="avatar">
        <?php print theme('imagecache', 'profile_photo', $image['filepath'], 'Picture of ' . $title); ?>
      </div>
    <?php endif; ?>
    <?php if($phone || $email || $websites): ?>
      <div class="contact_area">
        <h3>Contact</h3>
        <?php if($websites): ?>
          <ul>
            <?php foreach(array_unique($artist_sites) as $site): ?>
              <li><a href="<?php print $site->url; ?>" target="_blank"><?php print $site->url; ?></a>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
        <?php if($phone): ?><div class="phone-number"><?php print $phone; ?></div><?php endif; ?>
        <?php if($email): ?><div class="email-address"><a href="mailto:<?php print $email; ?>"><?php print $email; ?></a></div><?php endif; ?>
      </div>
    <?php endif; ?>
    <?php if ($node->field_sf_open_studios_wk1[0]['value']): ?>
      <div class="sfos_area">
        <h3>SF Open Studios</h3>
        <?php
        if ($node->field_sf_open_studios_wk1[0]['value']) {
          $term1 = taxonomy_get_term($node->field_sf_open_studios_wk1[0]['value']);
          $parent1 = array_pop(taxonomy_get_parents($term1->tid));
          $weekend1 = intval(array_pop(explode(' ', trim(array_shift(explode('-', $parent1->name))))));
          
          if ($node->field_sf_open_studios_wk2[0]['value']) {
            $term2 = taxonomy_get_term($node->field_sf_open_studios_wk2[0]['value']);
            $parent2 = array_pop(taxonomy_get_parents($term2->tid));
            $weekend2 = intval(array_pop(explode(' ', trim(array_shift(explode('-', $parent2->name))))));
            if($weekend1 < $weekend2) {
              display_openstudios_weekend('1', $term1, $parent1, $contact);
              display_openstudios_weekend('2', $term2, $parent2, $contact);
            }
            else {
              display_openstudios_weekend('2', $term2, $parent2, $contact);
              display_openstudios_weekend('1', $term1, $parent1, $contact);
            }
          }
          else {
            display_openstudios_weekend('1', $term1, $parent1, $contact);
          }
        }
        ?>
      </div>
    <?php endif; ?>
    <?php if(false)://($contact['address']['display']): ?>
      <div class="studio_area">
        <h3>Studio Address</h3>
        <?php print $contact['address']['display']; ?></p>
      </div>
    <?php endif; ?>
    <?php if($statement): ?>
      <div class="statement_area">
        <h3>Artist Statement</h3>
        <?php print $statement; ?>
      </div>
    <?php endif; ?>
    <?php if($twitter || $facebook): ?>
      <div class="social_area">
        <?php if($twitter): ?>
          <a href="<?php echo $twitter->url; ?>" class="twitter-link" target="_blank"><img src="<?php echo base_path() . path_to_theme(); ?>/images/twitter_profile_button.gif" alt="View this artist's Twitter account"></a>
        <?php endif; ?>
        <?php if($facebook): ?>
          <a href="<?php echo $facebook->url; ?>" class="facebook-link" target="_blank"><img src="<?php echo base_path() . path_to_theme(); ?>/images/facebook_profile_button.gif" alt="View this artist's Facebook account"></a>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
<?php endif; ?>

<div class="artwork">
  <?php print views_embed_view('artwork', 'block_1', arg(1)); ?>
</div>
<?php //print_r($node); ?>
