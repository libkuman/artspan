$(document).ready(function(){
  var twoWeekends = false;
  var numTiffUploads = 0;
        
  $('.credit_card_type-section label').append(' <span class="marker">*</span>');
  $('.credit_card_number-section label').append(' <span class="marker">*</span>');
  $('.cvv2-section label').append(' <span class="marker">*</span>');
  $('.credit_card_exp_date-section label').append(' <span class="marker">*</span>');
  $('.billing_first_name-section label').append(' <span class="marker">*</span>');
  $('.billing_last_name-section label').append(' <span class="marker">*</span>');
  $('.billing_street_address-5-section label').append(' <span class="marker">*</span>');
  $('.billing_city-5-section label').append(' <span class="marker">*</span>');
  $('.billing_postal_code-5-section label').append(' <span class="marker">*</span>');
  $('.custom_16-section label').append(' <span class="marker">*</span>');
  $('.custom_14-section label').append(' <span class="marker">*</span>');
  $('.custom_58-section label').append(' <span class="marker">*</span>');
  $('.custom_60-section label').append(' <span class="marker">*</span>');
  $('.custom_56-section label').append(' <span class="marker">*</span>');
  $('.custom_57-section label').append(' <span class="marker">*</span>');
  $('.custom_59-section label').append(' <span class="marker">*</span>');
  $('.custom_61-section label').append(' <span class="marker">*</span>');
  $('#studio_artist_name').parents('.crm-section').find('label').append(' <span class="marker">*</span>');
  $('#url-1-website_type_id').val(6);
  
  // remove broken js events (... hack ...)
  $(".paid_event-section input[type='radio']").attr('onClick', '');

  // Differences based on type of registration
  (function() {
    var handleMultipleWeekends = function() {
      var clicked_id = $(".paid_event-section input[type='radio']:checked").attr('id');
      var label = $("label[for=" + clicked_id + "]").text();
      var guide_section = $('.custom_16-section').parents('fieldset').not('.crm_user-group');
      var label_wkend_1 = $('#weekend_1 label[for=studio_weekend_no]');
      var label_wkend_2 = $('#weekend_2 label[for=studio_weekend_no_2]');

      if (label.search(/2 weekends/i) >= 0) {
        $('#weekend_2, .weekend_2').show();
        label_wkend_1.text('First Participating Weekend/Location');
        label_wkend_2.text('Second Participating Weekend/Location');
        twoWeekends = true;
      } else {
        $('#weekend_2, .weekend_2').hide(); 
        label_wkend_1.text('Participating Weekend/Location');
        twoWeekends = false;
      }

      if (label.search(/premier/i) >= 0) {
        guide_section.show();
        if(label.search(/2 weekends/i) >= 0 && label.search(/combo/i) < 0) {
          guide_section.find('.weekend_2').show();
          label_wkend_1.text('First Premier Weekend/Location');
          label_wkend_2.text('Second Premier Weekend/Location');
          numTiffUploads = 2;
        }
        else {
          guide_section.find('.weekend_2').hide();
          label_wkend_1.text('Premier Weekend/Location');
          label_wkend_2.text('Participating Weekend/Location');
          numTiffUploads = 1;
        }
      }
      else {
        guide_section.hide();
        numTiffUploads = 0;
      }

    };
    $('.paid_event-section input').click(handleMultipleWeekends);
    handleMultipleWeekends();
  })();

  // Guide artwork
  (function() {
    var guide_section = $('.custom_16-section').parents('fieldset').not('.crm_user-group');
    var children = guide_section.children().not('legend');
    var half = children.size() / 2;
    guide_section.append('<div class="weekend_block premier weekend_1"></div>');
    guide_section.append('<div class="weekend_block premier weekend_2"></div>');
    guide_section.children().not('legend, .weekend_block').each( function(i) {
      if(i < half) {
        $(this).appendTo($('.weekend_1'));
      }
      else {
        $(this).appendTo($('.weekend_2'));
      }
    });
  })();

  // Validation & next/prev buttons.
  (function() {
    var validate = function (element, message, f, element_section) {
      var jElement = $(element);
      var test;

      if(message === undefined) {
        message = 'This is a required field.';
      }
      if(typeof f !== 'function') {
        f = function() {
          return ($(this).val() !== '');
        }
      }

      if(!jElement.data('validator')) {
        test = function() {
          var section = element_section || jElement.parents('.crm-section');
          if(f.apply(element)) {
            section.data('error', false);
            section.find('label').removeClass('crm-error');
            section.find('.crm-error').remove();
            return true;
          }
          else if(!section.data('error')) {
            section.find('label').addClass('crm-error');
            jElement.after('<div class="crm-error">' + message + '</div>');
            section.data('error', true);
          }
          return false;
        }
        jElement.change(test);
        jElement.data('validator', test);
      }
      else {
        test = jElement.data('validator');
      }

      return test();
    }

    var groupValidate = function(group) {
      var allPassed = true;
      var element;
      for(i in group) {
        element = group[i];
        if(!validate(element.ref, element.message, element.validator, element.section)) {
          allPassed = false;
        }
      }
      return allPassed;
    }
    
    var emailValidator = function() {
      var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
      return reg.test($(this).val());
    }

    $('.go-to-form-1').click( function() {
      $('#form2_registration').hide();
      $('#form3_registration').hide();
      $('#form1_registration').show();
      cj.scrollTo(0);
      return false;
    });

    $('.go-to-form-2').click( function() {
      var accountValid = ($(this).parents('#form1_registration').size() <= 0 || groupValidate([
        {
          ref: $('#cms_name'),
          section: $('#cms_name').parents('.cms_name-section')
        },
        { ref: $('#email-5') },
        { 
          ref: $('#cms_pass'),
          section: $('#cms_pass').parents('.cms_pass-section')
        },
        {
          ref: $('#cms_confirm_pass'),
          section: $('#cms_confirm_pass').parents('.crm_confirm_pass-section'),
          message: "Passwords don't match.",
          validator: function() {
            return $(this).val() == $('#cms_pass').val();
          }
        }
      ]));

      if(accountValid) {
        $('#form1_registration').hide();
        $('#form3_registration').hide();
        $('#form2_registration').show();
        cj.scrollTo(0);
      }
      else {
        cj.scrollTo('.crm-error');
      }

      return false;
    });

    $('.go-to-form-3').click( function() {
      // Make sure required values are set
      var selectWeekendValidator = function() {
        return ($(this).find('[label^=--]:selected').size() > 0);
      }
      var groupLocationValidator = function() {
        return ($(this).val() != 0);
      }
      var tiffValidator = function() {
        return ($(this).val().match(/tiff?$/));
      }

      var allGroup = groupValidate([
        { ref: $("#first_name") },
        { ref: $("#last_name") },
        { ref: $("#phone-1-1") },
        { ref: $("#street_address-Primary") },
        { ref: $("#city-Primary") },
        { ref: $("#state_province-Primary") },
        { ref: $("#postal_code-Primary") },
        { ref: $("#studio_artist_name") },
        {
          ref: $("select[name=studio_weekend_no]"),
          validator: selectWeekendValidator,
          message: 'Please select a location.'
        }
      ]);

      var firstGroupSite = ($('[name=group_site]:checked').val() === 'no' || groupValidate([
        {
          ref: $("[name=studio_group_location]"),
          validator: groupLocationValidator,
          message: "Please select a group location."
        }
      ]));

      var firstNonGroupSite = ($('[name=group_site]:checked').val() === 'yes' || groupValidate([
        { ref: $('#studio_address') },
        { ref: $('#studio_city') },
        { ref: $('#studio_zip') }
      ]));

      var secondWeekend = (!twoWeekends || groupValidate([
        {
          ref: $("select[name=studio_weekend_no_2]"),
          validator: selectWeekendValidator,
          message: "Please select a location."
        }
      ]));

      var secondGroupSite = (!twoWeekends || $('[name=group_site_2]:checked').val() === 'no' || groupValidate([
        {
          ref: $("[name=studio_group_location_2]"),
          validator: groupLocationValidator,
          message: "Please select a group location."
        }
      ]));

      var secondNonGroupSite = (!twoWeekends || $('[name=group_site_2]:checked').val() === 'yes' || groupValidate([
        { ref: $('#studio_address_2') },
        { ref: $('#studio_city_2') },
        { ref: $('#studio_zip_2') }
      ]));

      var firstArtwork = (numTiffUploads < 1 || groupValidate([
        {
          ref: $('#custom_16'),
          validator: tiffValidator,
          message: "Please upload a .tif or .tiff file."
        },
        { ref: $('#custom_14') },
        { ref: $('#custom_58') },
        { ref: $('#custom_60') }
      ]));

      var secondArtwork = (numTiffUploads < 2 || groupValidate([
        {
          ref: $('#custom_56'),
          validator: tiffValidator,
          message: "Please upload a .tif or .tiff file."
        },
        { ref: $('#custom_57') },
        { ref: $('#custom_59') },
        { ref: $('#custom_61') }
      ]));

      if(allGroup && firstGroupSite && firstNonGroupSite && secondWeekend && secondGroupSite && secondNonGroupSite
         && firstArtwork && secondArtwork) {
        $('#form1_registration').hide();
        $('#form2_registration').hide();
        $('#form3_registration').show();
        cj.scrollTo(0);
      }
      else {
        cj.scrollTo('.crm-error');
      }
      
      return false;
    });
  })();

  // Autofilling elements based on other elements.
  (function() {
    var updateEmail = function () {
      if($('#custom_29').val() === '') {
        $('#custom_29').val($('#email-5').val());
      }
    };

    var updateArtistName = function () {
      if($('#studio_artist_name').val() === '') {
        $('#studio_artist_name').val($('#first_name').val() + ' ' + $('#last_name').val());
      }
    };

    var updatePublicPhone = function () {
      if($("#custom_46").val()) {
        $("#custom_30").val($('#' + $("#custom_46").val()).val());
      }
    }

    $('#email-5').change( updateEmail );
    updateEmail();

    $('#first_name, #last_name').change( updateArtistName );
    updateArtistName();

    $('#custom_46').change( updatePublicPhone );
    updatePublicPhone();
  })();

  // Disable nonselectable options in select list.
  (function() {
    $('select[name^=studio_weekend_no] option').not('[label^=--]').attr('disabled', 'true');
  })();
});
